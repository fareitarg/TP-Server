#!/bin/bash
# Grupo: 404 Grupo Not Found - Guillermo Gambirassi, Santiago Pittaro y Franco Trione.
if [[ "$1" == "-help" ]]; then
	echo "+-------------------------USO--------------------------+"
	echo "| $0 -o <origen> [-d <destino>]                        |"
	echo "+------------------------------------------------------+"
	echo " |_. Realiza un backup del directorio origen con el formato YYMMDD."
	echo " |_. Si no se pone el argumento -d, el directorio de destino por default es /backup_dir."
	echo " |_. Alias: backupfull."
	echo " |_.'-ej' para un ejemplo de uso."
exit 0
fi
if [[ "$1" == "-ej" ]]; then
	echo "+--------Ejemplo---------+"
	echo "| backupfull -o /var/log |"
	echo "+------------------------+"
	echo " |_.Utilizando el alias."
exit 0
fi
#Variables
DESTINO="/backup_dir"
ORIGEN=""
FECHA_err=$(date +"%c")
# Verificación de argumentos.
while [[ $# -gt 0 ]]; do
	case "$1" in
		-o)if [[ -z "$2" || "$2" == -* ]]; then
			echo "$FECHA_err -> Error. Falta el valor para '-o'. Consultar '-help'." >&2
			exit 1
		   fi
			ORIGEN="$2"; shift 2 ;;
		-d)if [[ -z "$2" || "$2" == -* ]]; then
			echo "$FECHA_err -> Error. Falta el valor para '-d'. Consultar '-help'." >&2
			exit 1
		   fi
			DESTINO="$2"; shift 2 ;;
		*)echo "${FECHA_err} -> Error. Argumento desconocido: '$1'. Consultar '-help'." >&2; exit 1 ;;
	esac
done
#Si origen está vacío
if [[ -z "$ORIGEN" ]]; then
	echo "$FECHA_err -> Error. Falta el argumento obligatorio '-o'. Consultar '-help'." >&2
	exit 1
fi
#Si se intenta backupear todo el sistema
if [[ "$ORIGEN" == "/" ]]; then
	echo "$FECHA_err -> Error. No se puede comprimir y backupear el directorio '/'." >&2
	exit 1
fi
#Si los directorios no existen
if [[ ! -d "$ORIGEN" ]]; then
	echo "$FECHA_err -> Error. El directorio '$ORIGEN' no existe. Revisar la sintaxis." >&2
	exit 1
elif [[ ! -d "$DESTINO" ]]; then
	echo "$FECHA_err -> Error. El directorio '$DESTINO' no existe:"
	read -p "¿Deseas crear el directorio? (s/n): " PREGUNTA
	while [[ ! "$PREGUNTA" =~ ^[sSnN]$ ]]; do
		read -p "Respuesta inválida. ¿Deseas crear el directorio? (s/n): " PREGUNTA
	done
	if [[ "$PREGUNTA" =~ ^[sS]$ ]]; then
		mkdir -p "$DESTINO"
	else
		exit 1
	fi
fi
#Variables para el nombre del archivo
FECHA=$(date +%Y%m%d)
NOMBRE_dir=$(basename "$ORIGEN")
ARCH="${NOMBRE_dir}_bkp_$FECHA.tar.gz"
#El backup
tar --ignore-failed-read -czf "$DESTINO/$ARCH" -C "$(dirname "$ORIGEN")" "$(basename "$ORIGEN")"

echo ""
echo "+-----------------------------------------------+"
echo "| Se creó correctamente el backup en $DESTINO|"
echo "+-----------------------------------------------+"
echo "  |_.Nombre de archivo: $ARCH."
echo "  |_.Fecha de creación: $FECHA_err."
echo ""

exit 0
